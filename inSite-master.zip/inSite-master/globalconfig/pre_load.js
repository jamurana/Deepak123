/// this config script is run automatically at the end of inSite setup, before loading the dataconfig file

console.log("pre-config run, project count: " + INSITEProjects.length);

