## AUAV inSite&trade; Documentation


The inSite docs are written in Markdown. To generate the HTML docs use Mkdocs:
https://www.mkdocs.org/

```
python -m pip install mkdocs
cd [inSite]/docs/
mkdocs build
```

This will then generate the static HTML docs in [inSite]/docs/site

